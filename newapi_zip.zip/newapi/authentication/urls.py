from django.urls.conf import path


urlpatterns = [
    

]
